import java.io.Serializable;

@SuppressWarnings("serial")

public class FileInfo implements Serializable
{
	public int peerid;
	public String fileName;
	public int portNumber;
}